<div class="sidebar-area mt-5">
  <?php
    dynamic_sidebar('fashion-boutique-sidebar');
  ?>
</div>